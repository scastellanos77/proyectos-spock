package org.example;

public class CityInfo {
    public String cityName;
    public long population;

    public CityInfo(String cityName,long population){
        this.cityName = cityName;
        this.population = population;
    }
}
